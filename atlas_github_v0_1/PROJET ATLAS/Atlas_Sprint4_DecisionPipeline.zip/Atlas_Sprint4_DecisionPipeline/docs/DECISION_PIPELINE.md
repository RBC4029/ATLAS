# Atlas Sprint 4 — Decision Pipeline

Implémentation du raisonnement métier validé :

1. Analyse de la déclaration et des circonstances.
2. Vérification du contrat actif.
3. Vérification de la garantie par rapport aux circonstances.
4. Si garantie probablement acquise : étape suivante.
5. Vérification convention IRSI pour DDE MRH avec tiers.
6. Vérification complétude du dossier.
7. Recommandation : dossier incomplet, analyse gestionnaire, téléexpertise/indemnisation directe à étudier.

Note :
Dans ce prototype, le contrat actif est simulé. Dans une vraie version, il viendra du SI assureur.
