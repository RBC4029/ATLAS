# Roadmap

Sprint A
- API
- Brain

Sprint B
- React
- Authentification

Sprint C
- Upload PDF
- OCR
- IA

Sprint D
- Connecteurs SI
