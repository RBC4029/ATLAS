from fastapi import APIRouter
from pydantic import BaseModel

router=APIRouter(prefix="/claims",tags=["claims"])

class Claim(BaseModel):
    text:str

@router.post("/analyze")
def analyze(claim:Claim):
    text=claim.text.lower()
    branch="MRH" if any(x in text for x in ["fuite","eau","parquet","plafond"]) else "AUTO" if any(x in text for x in ["collision","voiture","véhicule","pare-brise"]) else "UNKNOWN"
    convention=None
    if branch=="MRH" and "voisin" in text:
        convention="IRSI"
    if branch=="AUTO":
        convention="IRSA / IDA"
    return {
      "branch":branch,
      "convention":convention,
      "next_step":"Coverage Analyzer"
    }
