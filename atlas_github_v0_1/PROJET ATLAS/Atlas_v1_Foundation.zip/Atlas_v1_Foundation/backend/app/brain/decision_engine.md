# Decision Engine

Pipeline

1. Circumstances Analyzer
2. Coverage Analyzer
3. Convention Analyzer
4. Completeness Analyzer
5. Expertise Analyzer
6. Estimate Analyzer
7. Recourse Analyzer
8. Decision
