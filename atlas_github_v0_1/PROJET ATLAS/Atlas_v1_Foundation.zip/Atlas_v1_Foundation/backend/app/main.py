from fastapi import FastAPI
from app.api.claims import router

app=FastAPI(title="Atlas API")
app.include_router(router)

@app.get("/")
def health():
    return {"status":"ok","product":"Atlas"}
