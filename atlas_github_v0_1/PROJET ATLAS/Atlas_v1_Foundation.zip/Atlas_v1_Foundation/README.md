# Atlas v1 Foundation

Objectif :
Construire un copilote IA pour les gestionnaires sinistres.

Architecture :
- frontend : interface
- backend : API FastAPI
- brain : moteur de décision
- knowledge-base : règles métier
