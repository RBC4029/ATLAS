
# Intégration assureur

Atlas ne remplace pas le SI sinistre.

Modes d'intégration :
1. Copilot Web : l'utilisateur ouvre Atlas à côté de son SI.
2. API : le SI envoie les dossiers à Atlas via POST /claims/analyze.
3. Widget : Atlas est intégré dans un panneau latéral du SI existant.
4. Connecteur GED : Atlas lit les documents entrants et prépare les fiches.
