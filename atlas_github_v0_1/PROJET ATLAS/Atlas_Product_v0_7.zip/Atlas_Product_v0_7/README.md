
# Atlas Product v0.7

Version produit plus structurée : backend FastAPI + frontend démo + Atlas Brain + règles métier.

## Lancer rapidement la démo sans installation
Ouvrir : `frontend/index.html`

## Pour développeur
Backend FastAPI dans `backend/`.

### Commandes
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API :
- GET `/health`
- POST `/api/v1/claims/analyze`
- GET `/api/v1/rules`
