
def has(text: str, words: list[str]) -> bool:
    return any(w in text for w in words)

def analyze_circumstances(text: str) -> dict:
    t = text.lower()
    result = {
        "branch": "UNKNOWN",
        "claim_type": "Non identifié",
        "cause": "Inconnue",
        "origin": "Inconnue",
        "third_party": "Inconnu",
        "probable_responsible": "Inconnu",
    }

    if has(t, ["fuite", "dégât des eaux", "eau", "plafond", "parquet", "canalisation", "évier", "toiture"]):
        result.update({"branch": "MRH", "claim_type": "Dégât des eaux", "cause": "Fuite / infiltration"})
        if has(t, ["voisin", "tiers", "dessus"]):
            result.update({"origin": "Voisin / tiers", "third_party": "Oui", "probable_responsible": "Voisin"})
        elif has(t, ["toiture"]):
            result.update({"origin": "Toiture"})
        elif has(t, ["canalisation", "évier"]):
            result.update({"origin": "Canalisation privative"})

    if has(t, ["incendie", "fumée", "feu", "court-circuit"]):
        result.update({"branch": "MRH", "claim_type": "Incendie", "cause": "Incendie / fumée"})

    if has(t, ["vol", "effraction", "cambriolage"]):
        result.update({"branch": "MRH", "claim_type": "Vol", "cause": "Effraction"})

    if has(t, ["accident", "collision", "véhicule", "auto", "pare-chocs", "voiture"]):
        result.update({"branch": "AUTO", "claim_type": "Collision", "cause": "Choc / événement automobile"})
        if has(t, ["tiers", "constat", "percuté"]):
            result.update({"third_party": "Oui", "probable_responsible": "Conducteur tiers"})

    if has(t, ["pare-brise", "bris de glace", "vitrage"]):
        result.update({"branch": "AUTO", "claim_type": "Bris de glace", "cause": "Bris de vitrage"})

    return result
