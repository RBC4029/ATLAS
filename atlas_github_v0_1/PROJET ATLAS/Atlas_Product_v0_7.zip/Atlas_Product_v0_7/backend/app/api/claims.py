
from fastapi import APIRouter
from app.models.claim import ClaimAnalyzeRequest, ClaimAnalyzeResponse
from app.brain.decision_engine import analyze_claim

router = APIRouter(prefix="/claims", tags=["claims"])

@router.post("/analyze", response_model=ClaimAnalyzeResponse)
def analyze(req: ClaimAnalyzeRequest):
    return analyze_claim(req.text, req.claim_id or "DEMO", req.contract_active)
