
# Atlas Production v0.6

Version démo locale, sans installation.

## Lancer
Ouvrir `Atlas_Production_v0_6.html` dans un navigateur.

## Ajouts v0.6
- Rapport Atlas imprimable / exportable PDF via impression navigateur
- Meilleure fiche dossier
- Action immédiate recommandée
- Gestion plus claire de l’expertise / téléexpertise / indemnisation directe
- Dépôt documentaire simulé
- Exemples MRH, Auto, complexe
- Base de démonstration plus présentable pour rendez-vous

## Limites
- Pas encore de vraie IA
- Pas encore de vraie lecture PDF
- Pas de backend
- Contrat actif simulé
